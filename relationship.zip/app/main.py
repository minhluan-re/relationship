from fastapi import FastAPI
from app.db.database import Base, engin
from app.models.user_model import User

app = FastAPI()

Base.metadata.create_all(bind=engin)