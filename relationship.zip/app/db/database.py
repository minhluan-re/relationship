from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase

USER_NAME = "avnadmin"
PASSWORD = "AVNS_vXL13rKV8EPs7ne3dds"
HOST = "mysql-3dec04b7-mysql-learning.c.aivencloud.com"
PORT = "25172"
DATABASE_NAME = "fastapi"

DATABASE_URL = f"mysql+pymysql://{USER_NAME}:{PASSWORD}@{HOST}:{PORT}/{DATABASE_NAME}"

class Base(DeclarativeBase):
    pass

engin = create_engine(url=DATABASE_URL)

SessionLocal = sessionmaker(engin, autoflush=False)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()