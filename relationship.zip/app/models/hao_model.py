from database import Base
from sqlalchemy import Table, String, Integer, ForeignKey, Column
from sqlalchemy.orm import relationship


agent_skill = Table(
    "agent_skill",
    Base.metadata,
    Column(
        "agent_id",
        ForeignKey("agents.id"),
        primary_key=True
    ),
    Column(
        "skill_id",
        ForeignKey("skill.id"),
        primary_key = True
    )
)


class SupportTeam(Base):
    __tablename__ = "teams"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)

    agents = relationship(
        "SupportAgent",
        back_populates='team'
    )


class SupportAgent(Base):
    __tablename__ = "agents"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)


    team = relationship(
        "AgentProfile",
        back_populates="agent",
        uselist= False
    )


# class AgentProfile(Base):
#     __tablename__ = "agent_profiles"

#     id = Column(Integer, primary_key=True)
#     name = Column(String(100), nullable=False)

#     agent = relationship(
#         "SupportAgent",
#         back_popylates="profile"
#     )

# class Skill(Base):
#     __tablename__ = "skills"
#     id = Column(Integer, primary_key=True)
#     name = Column(String(100), nullable=False)

#     agents = relationship(
#         "SupportAgent"
#     )