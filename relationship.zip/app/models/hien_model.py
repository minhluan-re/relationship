from db.database import Base
from sqlalchemy import Table, Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship


agent_skills = Table(
    "agent_skills",
    Base.metadata,
    Column(
        "agent_id",
        ForeignKey("agents.id"),
        primary_key=True
    ),
    Column(
        "skill_id",
        ForeignKey("skills.id"),
        primary_key=True
    )
)


class SupportTeam(Base):
    __tablename__ = "teams"

    # id = Column(Integer, primary_key=True)
    # name = Column(String(100), nullable=False)

    # agents = relationship(
    #     "SupportAgent",
    #     back_populates="team"       # TODO 1
    # )


class SupportAgent(Base):
    __tablename__ = "agents"

    id = Column(Integer, Primary_key= True)
    name = Column(String(100), nullable=False)

    agent = relationship(
        "AgentProfile" ,
        back_populates= "agent",
        uselist = False
    ) 

class AgentProfile(Base):
    __tablename__ = "agent_profiles"

    id = Column(Integer, Primary_key=True)
    name = Column(String(100), nullable=False)

    agent = relationship(
        "Skill",
        back_populates= "profile"

    )

class Skill(Base):
    __tablename__ = "skills"
    id = Column(Integer, Primary_key=True)
    name = Column(String(100), nullable=False)
    

